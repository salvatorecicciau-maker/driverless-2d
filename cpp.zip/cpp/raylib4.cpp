#include "raylib.h"
#include <math.h>
#include <string>
#include <iomanip>
#include <sstream>
typedef struct {
    float rotation;
    float x,y;
    float v;
} player;

void updateplayer(player *car,float dt,int puntix[],int puntiy[]){

}

void DrawPlayer(player car){

}

void DrawPoint(int puntix[],int puntiy[]){
   
    for(int i=0;i<6;i++){
            DrawCircle(puntix[i],puntiy[i],3,RED);
    }

}

int main(void){
    int larg = 600;
    int lung = 600;
    InitWindow(larg, lung, "prova automatica");
    SetTargetFPS(60);
    float dt = GetFrameTime();
    player og = {0.0,larg/30.0,lung/30.0,20.0};
    int puntix[] = {20,20,100,250,330,100};
    int puntiy[] = {20,120,150,210,120,220};

    while(!WindowShouldClose()){
        //oggetto che segue un percorso;

        //creao una specie di buco nero?
        //oppure faccio una lista di punti con coordinate P1(x1,y1) , (...):


        BeginDrawing();
        DrawPoint(puntix,puntiy);
        EndDrawing();
    }
}