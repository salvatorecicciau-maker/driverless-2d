#include "raylib.h"
#include <stdio.h>
#include <iostream>
#include <cmath>

using namespace std;

#define PI 3.14
#define Car_Color RED
int main() {
    SetTargetFPS(60);
    int width =1000;
    int height = 900;
    float car_width = 25;
    float car_height = 50;
    float car_x = width/2;
    float car_y=height/2;
    float car_speed = 0;
    float car_speed_max = 10;
    int direction = -1;
    float car_rotation=-90;
    int car_curve = 1;
    Vector2 car_origin;

    InitWindow (1000, 900, "ciamo amore");
    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(RAYWHITE);
        float dt = GetFrameTime();

        if(IsKeyDown(KEY_UP)){         
            direction = -1;
            car_speed += 4 * dt;
            if(car_speed > car_speed_max){
                car_speed = car_speed_max;
            }
        }else if(IsKeyDown(KEY_DOWN)){
            direction = 1;
            car_speed -= 4 *dt;
            if(car_speed > car_speed_max){
                car_speed = car_speed_max;
            }
        }else{
            car_speed += 3*dt*direction;
            if(direction == -1 && car_speed < 0){
                car_speed = 0;
            }else if(direction == 1 && car_speed > 0){
                car_speed = 0;
            }
        }
        //car_rotation_speed = 50
        if(car_speed != 0){
                if(IsKeyDown(KEY_LEFT)){
                car_rotation -= 80*dt;
            }else if(IsKeyDown(KEY_RIGHT)){
                car_rotation += 80*dt;
            }
        
        }

        if(car_rotation <= -360){
            car_rotation = 0;
        }
        if(car_rotation >= 360){
            car_rotation = 0;
        }

        float rad = PI * car_rotation / 180;
        float x_move = car_speed * cosf(rad);
        float y_move = car_speed * sinf(rad);

        car_x += x_move;
        car_y += y_move;

        Rectangle car_rec = {
            .x = car_x,
            .y = car_y,
            .width = car_height,
            .height = car_width,
        };
        
        Vector2 car_origin = {
            .x = car_width/2,
            .y = car_height/2,
        };

        DrawRectanglePro(car_rec, car_origin, car_rotation, Car_Color);
        DrawText("passo 1", 100,100, 20, BLUE);


        EndDrawing();
    }

    CloseWindow();
    return 0;
}