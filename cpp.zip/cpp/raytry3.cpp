#include "raylib.h"
#include <cmath>
#include <stdio.h>
#include <iostream>

#define PI 3.14
using namespace std;

typedef struct {
    float x,y,theta,v,delta,L;
} macchina;

void Updatemacchina(macchina *car,float d){
    car->x += car->v * cosf(car->theta) * d;
    car->y += car->v * cosf(car->theta) * d;
    car->theta += (car->v / car->L) * tanf(car->delta) * d;
}

/*void Disegnoveicolo(macchina car){
    float rotation = car.theta * (180.0f/PI);
    Vector2 posizione = {
        car.x,
        car.y
    };
    Vector2 origin = {25,12.5f};
    Rectangle body = {
        car.x,
        car.y,
        25,
        25
    };
    DrawRectanglePro(body,origin,rotation,DARKBLUE);

    Rectangle body2= {
        car.x,
        car.y
    };
    Vector2 origin2= {15, 12.5f};
    DrawRectanglePro(body2,origin2,rotation,RED);

}*/

int main(){
    SetTargetFPS(60);
    InitWindow(800,800,"grazie amore");
    macchina car = {400.0f, 300.0f, 0.0f, 0.0f, 0.0f, 50.0f};
    float car_max_speed = 100; 
    float car_speed = 50;
    float car_rotation = 0.7;
    int c=0;
    float size = 20;

    while(!WindowShouldClose()){
        float d = GetFrameTime();
        c=0;
        //su e giu
        if(IsKeyDown(KEY_UP)){
            car.v += car_speed*d;
            c+=1;
        }else c+=0;
        if(IsKeyDown(KEY_DOWN)){
            car.v -=car_speed*d;
            c+=1;
        }else c+=0;

        //destra sinistra
        if(IsKeyDown(KEY_RIGHT)){
            car.delta = car_rotation;
        }else if(IsKeyDown(KEY_LEFT)){
            car.delta = -1*car_rotation;
        }else car.delta = 0.0f;

        Updatemacchina(&car,d);
        BeginDrawing();
        ClearBackground(RAYWHITE);
        Vector2 p = {car.x, car.y};
        float size = 20;
        Vector2 front = {p.x + cosf(car.theta) * size, p.y + sinf(car.theta) * size};
        DrawLineV(p, front, RED);
        DrawCircleV(p, 4, BLUE);
        EndDrawing();

    }
}