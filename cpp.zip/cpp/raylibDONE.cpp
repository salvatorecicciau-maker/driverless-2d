#include "raylib.h"
#include"raymath.h"
#include <math.h>
#include <string>
#include <iomanip>
#include <sstream>


typedef struct {
    float x, y;
    float theta;
    float v;
    float delta;
    float L;
} Vehicle;

void UpdateVehicle(Vehicle *car, float dt) {
    car->x += car->v * cosf(car->theta) * dt;
    car->y += car->v * sinf(car->theta) * dt;
    car->theta += (car->v / car->L) * tanf(car->delta) * dt;
}

void ruoteanteriori(Vehicle car){
    float rot = car.delta*13+car.theta * (180.0f / PI);
    Vector2 pos {pos.x,pos.y};
    Vector2 Odestra = {-5,-6};
    Vector2 Osinistra = {-5,10};
    Rectangle Rdestra = {pos.x,pos.y,10,4};
    Rectangle Rsinistra = { pos.x,pos.y,10,4};
    DrawRectanglePro(Rdestra,Odestra,rot,DARKGRAY);
    DrawRectanglePro(Rsinistra,Osinistra,rot,DARKGRAY);
}

void DrawMap1(){
    //x y
    Vector2 curva4 = {1200, 550};
    DrawCircleV(curva4,480,GRAY);

    Vector2 margine4 = {1200,550};
    DrawCircleV(margine4,320,WHITE);
    DrawRectangle(400,70,800,960,WHITE);

    //due parti della strada angolate
    //1:
    //+90°
    float rot = 26.5+90.0;
    Rectangle strada1 = {550,427,160,680};
    Vector2 origin1_strada = {80,280};
    DrawRectanglePro(strada1,origin1_strada,rot,GRAY);

        //2:
    float rot1=45.0;
    Rectangle strada2 = {1000,350,160,550};
    Vector2 origin2_strada = {80,280};
    DrawRectanglePro(strada2,origin2_strada,rot1,GRAY);

    Vector2 curva1 = {200,250};
    DrawCircleV(curva1,80,GRAY);
    Vector2 curva2 = {800,550};
    DrawCircleV(curva2,80,GRAY);
    Vector2 curva3 = {1200,150};
    DrawCircleV(curva3,80,GRAY);
    Vector2 curva5 = {200,950};
    DrawCircleV(curva5,80,GRAY);
    DrawRectangle(200,870,1000,160,GRAY);
    DrawRectangle(120,250,160,700,GRAY);



}
void  DrawCar2(Vehicle c){
    Vector2 pos = { c.x, c.y };
    float rotation = c.theta * (180.0f / PI);

    //ruote: 
    Vector2 ruota_sinistras = {17, 10};
    Rectangle  ruotass = {pos.x, pos.y, 10 , 6};
    DrawRectanglePro(ruotass,ruota_sinistras,rotation,BLACK);

    Vector2 ruota_destras = {17, -5};
    Rectangle ruotads = {pos.x,pos.y,10,6};
    DrawRectanglePro(ruotads,ruota_destras,rotation,BLACK);


    //body del vehicle:
    Vector2 origin = { 18, 7 };
    Vector2 origin1 = {18,4.5};
    Vector2 origin2 = {-18,10};
    Vector2 origin3 = {28, 10};
    Vector2 origin4 = {-10,8};

    Vector2 cold = {24,5.5};
    Vector2 cols = {24,-4.5};

    Rectangle alettone = {pos.x,pos.y, 5,20};
    Rectangle body = { pos.x, pos.y, 20, 15 };
    Rectangle front = { pos.x,pos.y, 36,10};
    Rectangle frontv = {pos.x,pos.y,5,20};
    Rectangle asses = {pos.x,pos.y,3,16};

    Rectangle coldd = { pos.x,pos.y,20,2 };
    Rectangle colss = { pos.x,pos.y,20,2};

    DrawRectanglePro(coldd,cold,rotation,BLACK);
    DrawRectanglePro(colss,cols,rotation,BLACK);
    DrawRectanglePro(asses,origin4,rotation,BLACK);
    DrawRectanglePro(alettone,origin3,rotation,BLUE);
    DrawRectanglePro(front, origin1,rotation, BLUE);
    DrawRectanglePro(frontv, origin2,rotation,BLUE);
    DrawRectanglePro(body, origin, rotation, BLUE);
}

void DrawCar(Vehicle car) {
    Vector2 pos = { car.x, car.y };
    float rotation = car.theta * (180.0f / PI);

    //ruote: 
    Vector2 ruota_sinistras = {17, 10};
    Rectangle  ruotass = {pos.x, pos.y, 10 , 6};
    DrawRectanglePro(ruotass,ruota_sinistras,rotation,BLACK);

    Vector2 ruota_destras = {17, -5};
    Rectangle ruotads = {pos.x,pos.y,10,6};
    DrawRectanglePro(ruotads,ruota_destras,rotation,BLACK);


    //body del vehicle:
    Vector2 origin = { 18, 7 };
    Vector2 origin1 = {18,4.5};
    Vector2 origin2 = {-18,10};
    Vector2 origin3 = {28, 10};
    Vector2 origin4 = {-10,8};

    Vector2 cold = {24,5.5};
    Vector2 cols = {24,-4.5};

    Rectangle alettone = {pos.x,pos.y, 5,20};
    Rectangle body = { pos.x, pos.y, 20, 15 };
    Rectangle front = { pos.x,pos.y, 36,10};
    Rectangle frontv = {pos.x,pos.y,5,20};
    Rectangle asses = {pos.x,pos.y,3,16};

    Rectangle coldd = { pos.x,pos.y,20,2 };
    Rectangle colss = { pos.x,pos.y,20,2};

    DrawRectanglePro(coldd,cold,rotation,BLACK);
    DrawRectanglePro(colss,cols,rotation,BLACK);
    DrawRectanglePro(asses,origin4,rotation,BLACK);
    DrawRectanglePro(alettone,origin3,rotation,RED);
    DrawRectanglePro(front, origin1,rotation, RED);
    DrawRectanglePro(frontv, origin2,rotation,RED);
    DrawRectanglePro(body, origin, rotation, RED);
}


int main(void) {
    InitWindow(1800, 999, "amore funziona");
    SetTargetFPS(60);
    //int px[]={200,800,1200,1550,1300,200};
    //int py[]={250,550,150,550,950,950};
    float car_speed = 90 ;
    Vehicle car = {400.0f, 300.0f, 0.0f, 0.0f, 0.0f, 50.0f};
    //autonomo:
    Vehicle c = { 200, 200, 0, 0, 0, 30 };

    Vector2 waypoints[] = {
        {800,550},
        {1200,150},
        {1500,300},
        {1600,600},
        {1600,800},
        {1200,950},
        {200,950},
        {200,250}
    };

    int numcurva = 0;
    int total = 8;


    while (!WindowShouldClose()) {
        float dt = GetFrameTime();

        // Controlli utente
        if (IsKeyDown(KEY_UP)){
            car.v += car_speed * dt;
        }    
        if (IsKeyDown(KEY_DOWN)){
            car.v -= car_speed * dt + 5.0f;
        }
        if (IsKeyDown(KEY_LEFT)){
            car.delta = -0.3f;
        }else if (IsKeyDown(KEY_RIGHT)){
            car.delta = 0.3f; 
        }else car.delta = 0.0f;                        

        UpdateVehicle(&car, dt);



        //sec veicolo:
        Vector2 points = waypoints[numcurva];
        Vector2 pos2 = (Vector2){c.x,c.y};
        float distanza = Vector2Distance(pos2,points);
        float   wprad= 60.0f;

        if (distanza <wprad){
            numcurva = (numcurva+1) % total;
                }

        float desired = atan2f(points.y - c.y, points.x - c.x);
        float error = desired - c.theta;

        while (error > PI) error -= 2*PI;
        while (error < -PI) error += 2*PI;
        c.delta = error*1.7f;  
        
        if (c.delta > 0.5f) c.delta = 0.5f;
        if (c.delta < -0.5f) c.delta = -0.5f;
        c.v = 200;

        UpdateVehicle(&c,dt);




        // Disegno
        BeginDrawing();
        for (int i = 0; i < numcurva; i++){
            DrawCircleV(waypoints[i], 6, RED);
        }
        DrawMap1();
        ClearBackground(WHITE);
        DrawCar(car);
        DrawCar2(c);
        DrawText("Usa frecce per muoverti", 10, 10, 20, DARKGRAY);
        EndDrawing();
    }

    CloseWindow();
    return 0;
}
